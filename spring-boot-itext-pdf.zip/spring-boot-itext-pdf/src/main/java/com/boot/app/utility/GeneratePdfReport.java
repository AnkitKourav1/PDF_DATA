package com.boot.app.utility;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.boot.app.bean.City;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class GeneratePdfReport {

	public static ByteArrayInputStream citiesReport(List<City> cities) throws MalformedURLException, IOException {

		Document document = new Document();
		ByteArrayOutputStream out = new ByteArrayOutputStream();

		try {

			PdfPTable table = new PdfPTable(3);
			table.setWidthPercentage(60);
			table.setWidths(new int[] { 1, 3, 3 });

			Font headFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
//			table.addCell(logo);
			PdfPCell hcell;

			hcell = new PdfPCell(new Phrase("Id", headFont));

			hcell.setHorizontalAlignment(Element.ALIGN_MIDDLE);
			hcell.setBackgroundColor(new BaseColor(226, 226, 226));

			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Name", headFont));

			hcell.setHorizontalAlignment(Element.ALIGN_MIDDLE);
			hcell.setBackgroundColor(new BaseColor(226, 226, 226));

			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Population", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_MIDDLE);
			hcell.setBackgroundColor(new BaseColor(226, 226, 226));

			table.addCell(hcell);

			for (City city : cities) {

				PdfPCell cell;

				cell = new PdfPCell(new Phrase(city.getId().toString()));

				cell.setBackgroundColor(BaseColor.GREEN);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell.setUseAscender(true);

				table.addCell(cell);

				cell = new PdfPCell(new Phrase(city.getName()));
				cell.setPaddingLeft(5);
				cell.setBackgroundColor(BaseColor.GREEN);

				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(String.valueOf(city.getPopulation())));
				cell.setBackgroundColor(BaseColor.GREEN);

				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				cell.setPaddingRight(5);
				table.addCell(cell);
			}
			Image logo = Image.getInstance(GeneratePdfReport.class.getResource("/T-Mobile.jpg"));
			logo.setAbsolutePosition(0, 0);

			logo.scaleAbsoluteHeight(50);
			logo.scaleAbsoluteWidth((logo.getWidth() * 50) / logo.getHeight());
            logo.setAlignment(100);
			logo.setAlignment(Element.ALIGN_TOP);
			logo.setAbsolutePosition(15,40);
			logo.scalePercent(3.5f, 3.5f);

			// logo.setAbsolutePosition(70, 140);

			// Adding image to the document

			PdfWriter.getInstance(document, out);
			document.open();
			document.add(logo);
		
			Paragraph paragraph = new Paragraph();
			paragraph.add(table);

			table.setSpacingBefore(10);
			table.setSpacingAfter(15);

			paragraph.getPaddingTop();
			document.add(table);

			document.close();

		} catch (DocumentException ex) {

			Logger.getLogger(GeneratePdfReport.class.getName()).log(Level.SEVERE, null, ex);
		}

		return new ByteArrayInputStream(out.toByteArray());
	}
}
