package com.boot.app.service;

import java.util.stream.Stream;


public interface SampleService {
	public Stream<UserDetail> getAll();
}