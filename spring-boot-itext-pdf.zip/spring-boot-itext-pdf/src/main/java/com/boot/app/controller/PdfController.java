package com.boot.app.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.boot.app.bean.City;
import com.boot.app.service.ICityService;
import com.boot.app.utility.GeneratePdfReport;

@RestController
public class PdfController {
	@Autowired
	ICityService cityService;

	@RequestMapping(value = "/pdfreport", method = RequestMethod.GET, produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> citiesReport() throws IOException {

		City city = new City();
		city.setId((long) 12);
		city.setName("A");
		city.setPopulation(1200);

		List<City> cities = new ArrayList<City>();
		cities.add(city);

		ByteArrayInputStream bis = GeneratePdfReport.citiesReport(cities);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline; filename=citiesreport.pdf");

		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)

				.body(new InputStreamResource(bis));
	}

	@RequestMapping(value = "/writeCSV", method = RequestMethod.GET)
	public ResponseEntity<String> givenDataArray_whenConvertToCSV_thenOutputCreated() throws IOException {
		File csvOutputFile = new File("src/main/resources/data.csv");
		List<String[]> dataLines = new ArrayList<>();
		getData(dataLines);

		try (PrintWriter pw = new PrintWriter(csvOutputFile)) {
			dataLines.stream().map(this::convertToCSV).forEach(pw::println);
		}
		return ResponseEntity.ok().body("CSV Data Write Successfully");
	}

	private void getData(List<String[]> dataLines) {
		dataLines.add(new String[] { "FirstName", "LastName", "Age", "Comment" });
		dataLines.add(new String[] { "John", "Doe", "38", "Comment Data\nAnother line of comment data" });
		dataLines.add(new String[] { "Jane", "Doe, Jr.", "19", "She said \"I'm being quoted\"" });
	}

	public String convertToCSV(String[] data) {
		return Stream.of(data).map(this::escapeSpecialCharacters).collect(Collectors.joining(","));
	}

	public String escapeSpecialCharacters(String data) {
		String escapedData = data.replaceAll("\\R", " ");
		if (data.contains(",") || data.contains("\"") || data.contains("'")) {
			data = data.replace("\"", "\"\"");
			escapedData = "\"" + data + "\"";
		}
		return escapedData;
	}
	
	/*
	 * @RequestMapping(value = "/userdetail/stream/csv", method = RequestMethod.GET)
	 * 
	 * @Transactional(readOnly = true) public void
	 * generateCSVUsingStream(HttpServletResponse response) {
	 * response.addHeader("Content-Type", "application/csv");
	 * response.addHeader("Content-Disposition",
	 * "attachment; filename=user_details.csv");
	 * response.setCharacterEncoding("UTF-8"); try (Stream<UserDetail>
	 * userDetailsStream = sampleRepository.getAll();) { PrintWriter out =
	 * response.getWriter(); userDetailsStream.forEach(userDetail -> {
	 * out.write(userDetail.toString()); out.write("\n");
	 * entityManager.detach(userDetail); }); out.flush(); out.close();
	 * userDetailsStream.close(); } catch (IOException ix) { throw new
	 * RuntimeException("There is an error while downloading user_details.csv", ix);
	 * } }
	 */

	public static void main(String[] args) throws IOException {
		PdfController pfd = new PdfController();
		pfd.givenDataArray_whenConvertToCSV_thenOutputCreated();

	}
}
